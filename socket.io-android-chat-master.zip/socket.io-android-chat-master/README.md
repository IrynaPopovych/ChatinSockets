# socket.io-android-chat

This is a simple chat demo for socket.io and Android. You can connect to [chat.socket.io](http://socket.io/demos/chat/) using this app.

## Installation

1. Clone the project.
2. In Android Studio, chose **File > Import Project** and select the root folder of the project.
   Android Studio may ask you to choose the type of project you are importing. If this is the case, make sure to choose **Import project from external model** and select the **Gradle** option.

## Tutorial

http://socket.io/blog/native-socket-io-and-android/

## License

MIT

